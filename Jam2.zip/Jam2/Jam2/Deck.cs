﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jam2
{
    class Deck
    {
        int type; //Type of Deck
        List<Card> cards = new List<Card>(); //List of cards
        public void shuffle()
        {

        }
    }
}
